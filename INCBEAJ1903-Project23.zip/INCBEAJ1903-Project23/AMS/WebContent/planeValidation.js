function planeValidation()
{
	
var fname=document.plane.fname;	
var lname=document.plane.lname;	
var num=document.plane.num;
var email=document.plane.email;	
//var type=document.plane.type;	
var cap=document.plane.cap;
var check;
var count;
count=0;


check=/^[A-Za-z]+$/;
	if(fname.value.match(check))
	{
	}
	else
	{
		fname.style.backgroundColor="red";
		count=count+1;	
	}	
	


check=/^[A-Za-z]+$/;
	if (lname.value.match(check))
	{
	}
	else
	{
		lname.style.backgroundColor="red";
		count=count+1;
	}	
	

	check=/^[0-9]+$/;
	if (num.value.match(check))
	{
	
	}
	else
	{
		num.style.backgroundColor="red";
		count=count+1;
	}


var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(email.value.match(mailformat))
{

}
else
{
	email.style.backgroundColor="red";
	count=count+1;
}
	

check=/^[0-9]+$/;
	if (cap.value.match(check))
	{		
	}
	else
	{
		cap.style.backgroundColor="red";
		count=count+1;
	}
	
	if(count==0)
	{
	return true;
	}
else
	{
	alert("Fill the wrong details");
	return false;
	}
}