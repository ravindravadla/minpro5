function hangarStatusValidation()
{
	var m_id=Document.hangar.manager_id;
	var status=Document.hangar.status;
	var ofd=Document.hangar.ofd;
	var otd=Document.hangar.otd;
	var afd=Document.hangar.afd;
	var atd=Document.hangar.atd;
	
	var count;
	count=0;
	var check;
	
	check=/^[0-9]+$/;
	if (m_id.value.match(check))
	{

	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
	m_id.style.backgroundColor="red";
	count=count+1;
	//return false;
	}
	
	check=/^[A-Za-z]+$/;
	if (status.value.match(check))
	{

	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
	status.style.backgroundColor="red";
	count=count+1;
	//return false;
	}
	
	if (ofd.value.length>0)
	{

	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
	ofd.style.backgroundColor="red";
	count=count+1;
	//return false;
	}
	
	if (otd.value.length>0)
	{

	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
	otd.style.backgroundColor="red";
	count=count+1;
	//return false;
	}
	
	if (afd.value.length>0)
	{

	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
	afd.style.backgroundColor="red";
	count=count+1;
	//return false;
	}
	
	if (atd.value.length>0)
	{

	}
	else
	{
	//alert("First name should contains character");
	//fname.focus();
	atd.style.backgroundColor="red";
	count=count+1;
	//return false;
	}
	
	if(count==0)
	{
	return true;
	}
else
	{
	alert("Fill the wrong details");
	return false;
	}
}