package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UpdateHangarDAO {
	public String getHangarDetails(String id)
	{
				  
	       try
	       {
	              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              	              
	              PreparedStatement pstmt=con.prepareStatement("select * from hangar where hangar_id=?;");   
	              pstmt.setInt(1, Integer.parseInt(id));
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              if(rs.next())
	              {
	            	planes.append("<html><head><title>Update Hangar Details</title></head><body><center><form align=\"center\" action=\"UpdateHangarPageServlet\" method=\"post\"style=\"margin:100px 50px;\"><table><tr><td>Hangar ID:</td><td><input type=\"number\" name=\"id\" value=\""+id+"\"</td></tr><tr><td>Manager ID:</td><td><input type=\"text\" name=\"mid\" value=\""+rs.getString(2)+"\"></td>");
	            	planes.append("</tr><tr><td>Address 1:</td><td><input type=\"text\" name=\"addr1\" value=\""+rs.getString(3)+"\"></td></tr><tr><td>Address 2:</td><td><input type=\"text\" name=\"addr2\" value=\""+rs.getString(4)+"\"></td></tr><tr><td>City:</td><td><input type=\"text\" name=\"city\" value=\""+rs.getString(5)+"\"></td></tr><tr><td>State:</td><td><input type=\"text\" name=\"state\" value=\""+rs.getString(6)+"\"></td></tr>");
	            	planes.append("<tr><td>Zip Code:</td><td><input type=\"text\" name=\"zipcode\" value=\""+rs.getString(7)+"\"></td><td><input type=\"submit\" value=\"submit\"></td></tr></table>	</form></center></body>	</html>");
	              }
	              return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
	}
}
