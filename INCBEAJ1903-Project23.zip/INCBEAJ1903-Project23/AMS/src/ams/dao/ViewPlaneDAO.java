package ams.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewPlaneDAO {
	public String getID()
	{
	       
	       try
	       {              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              
	              
	              PreparedStatement pstmt=con.prepareStatement("select plane_id from planes");   
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              planes.append("<form action=\"ViewPlanePageServlet\">");
	              while(rs.next())
	              {
	            	  planes.append("<input type=\"submit\" name=\"ups\" value=\"");
	            	  planes.append(rs.getString(1));
	            	  planes.append("\">");
	            	  planes.append("</input><br><br>");	            	 
	              }
	              planes.append("</form>");
	              System.out.println(planes);
	              return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
}
	public String getPlaneDetails(String id)
	{
				  
	       try
	       {
	              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              	              
	              PreparedStatement pstmt=con.prepareStatement("select * from planes where plane_id=?;");   
	              pstmt.setInt(1, Integer.parseInt(id));
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              if(rs.next())
	              {
	            	  planes.append("<html><body>");
	            	  planes.append("<style>table,tr,td{border:1px solid black;}</style>");
	            	  planes.append("<table>");
	            	  planes.append("<tr><td>Plane ID:</td><td>"+rs.getInt(1));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Owner ID:</td><td>"+rs.getInt(2));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Owner First Name:</td><td>"+rs.getString(3));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Owner Last Name:</td><td>"+rs.getString(4));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Owner Number:</td><td>"+rs.getString(5));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Owner Email:</td><td>"+rs.getString(6));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Plane Type:</td><td>"+rs.getString(7));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Plane Capacity:</td><td>"+rs.getInt(8));
	            	  planes.append("</td></tr></table>");
	            	  planes.append("<form action=\"UpdatePlaneServlet\"><input type=\"submit\" name=\"ups\" value=\""+id+"\">");
	            	  planes.append("Update Plane</input></form>");
	            	  planes.append("</body></html>");
	              }
	              return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
	}
}
