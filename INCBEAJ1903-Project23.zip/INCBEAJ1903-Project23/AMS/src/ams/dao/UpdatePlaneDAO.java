package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UpdatePlaneDAO {
	/*public String getID()
	{
	       
	       try
	       {              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              
	              
	              PreparedStatement pstmt=con.prepareStatement("select plane_id from planes");   
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              planes.append("<form action=\"ViewPlanePageServlet\">");
	              while(rs.next())
	              {
	            	  planes.append("<input type=\"submit\" name=\"ups\" value=\"");
	            	  planes.append(rs.getString(1));
	            	  planes.append("\">");
	            	
	            	  planes.append("</input><br>");
	            	 
	              }
	              planes.append("</form>");
	              System.out.println(planes);
	              return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
}*/
	public String getPlaneDetails(String id)
	{
				  
	       try
	       {
	              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              	              
	              PreparedStatement pstmt=con.prepareStatement("select * from planes where plane_id=?;");   
	              pstmt.setInt(1, Integer.parseInt(id));
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              if(rs.next())
	              {
	            	planes.append("<html><head><title>Update Planes Details</title></head><body><center><form align=\"center\" action=\"UpdatePlanePageServlet\" method=\"post\"style=\"margin:100px 50px;\"><table><tr><td>Plane ID:</td><td><input type=\"number\" name=\"id\" value=\""+id+"\"</td></tr><tr><td>Owner First Name:</td><td><input type=\"text\" name=\"fname\" value=\""+rs.getString(3)+"\"></td>");
	            	planes.append("</tr><tr><td>Owner Last Name:</td><td><input type=\"text\" name=\"lname\" value=\""+rs.getString(4)+"\"></td></tr><tr><td>Owner Contact Number:</td><td><input type=\"text\" name=\"num\" value=\""+rs.getString(5)+"\"></td></tr><tr><td>Owner Email Id:</td><td><input type=\"text\" name=\"email\" value=\""+rs.getString(6)+"\"></td></tr><tr><td>Plane Type:</td><td><input type=\"text\" name=\"type\" value=\""+rs.getString(7)+"\"></td></tr>");
	            	planes.append("<tr><td>Plane Capacity:</td><td><input type=\"text\" name=\"cap\" value=\""+rs.getInt(8)+"\"></td></tr><tr><td><input type=\"submit\" value=\"submit\"></td></tr></table>	</form></center></body>	</html>");
	              }
	              return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
	}
}
