package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import ams.model.AdminModel;

public class AdminRegisterDAO {

	public boolean insertDatabase(AdminModel am)
	{
	       
	       try
	       {
	              //System.out.println(user+"\t"+pass);
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              
	            
	              PreparedStatement pstmt=con.prepareStatement("insert into admin(first_name,last_name,age,gender,Dob,con_num,alt_con_num,email_id,password) values(?,?,?,?,?,?,?,?,?);");
	             
	              pstmt.setString(1,am.getFirstName());
	              pstmt.setString(2,am.getLastName());
	              pstmt.setInt(3,Integer.parseInt(am.getAge()));
	              pstmt.setString(4,am.getGender());
	              pstmt.setString(5,am.getDob());
	              pstmt.setString(6,am.getContactNumber());
	              pstmt.setString(7,am.getAlternateContactNumber());
	              pstmt.setString(8,am.getEmaiLId());
	              pstmt.setString(9,am.getPassword());
	              
	              int rec=pstmt.executeUpdate();   
	              System.out.println(rec);
	              if(rec>0)
	              {
	                     System.out.println(rec);
	                     return true;
	              }
	              else
	              {
	                     System.out.println("No record");
	                     return false;
	              }

	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return false;
	       }
	}
}
