package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import ams.model.HangarModel;

public class AddHangarDAO {
	public boolean insertDatabase(HangarModel hm)
	{
	       
	       try
	       {
	              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              PreparedStatement pstmt=con.prepareStatement("insert into Hangar(manager_id,address1, address2,city,state,zipcode) values(?,?,?,?,?,?);");
	              
	             pstmt.setInt(1,Integer.parseInt(hm.getManagerId()));
	              pstmt.setString(2,hm.getAddress1());
	              pstmt.setString(3,hm.getAddress2());
	              pstmt.setString(4,hm.getCity());
	              pstmt.setString(5,hm.getState());
	              pstmt.setInt(6,Integer.parseInt(hm.getZipcode()));
	             
	             
	             int rec=pstmt.executeUpdate();   
	             System.out.println(rec);
	              if(rec>0)
	              {
	                     System.out.println(rec);
	                     return true;
	              }
	              else
	              {
	                     System.out.println("No record");
	                     return false;
	              }

	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return false;
	       }
	}
}
