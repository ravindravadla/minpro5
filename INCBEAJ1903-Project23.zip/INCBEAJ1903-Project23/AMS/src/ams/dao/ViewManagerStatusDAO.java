package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class ViewManagerStatusDAO {
	public String viewManagerStatus()
	{
	      StringBuffer sb=new StringBuffer(); 
	       try
	       {
	              //System.out.println(user+"\t"+pass);
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              
	             
	              PreparedStatement pstmt=con.prepareStatement("select distinct manager_id,status from manager_status;");
	             ResultSet rs=pstmt.executeQuery();
	             sb.append("<html><body><table>");
	             while(rs.next())
	             {
	            	 sb.append("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td></tr>");
	             }
	             sb.append("</table></body></html>");

	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	             
	       }
	       return sb.toString();
	}
}
