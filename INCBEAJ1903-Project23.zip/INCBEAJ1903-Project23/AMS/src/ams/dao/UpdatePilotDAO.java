package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UpdatePilotDAO {
	public String getPilotDetails(String id)
	{
				  
	       try
	       {
	              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              	              
	              PreparedStatement pstmt=con.prepareStatement("select * from pilots where pilot_id=?;");   
	              pstmt.setInt(1, Integer.parseInt(id));
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              if(rs.next())
	              {
	            	planes.append("<html><head><title>Update Pilot Details</title></head><body><center><form align=\"center\" action=\"UpdatePilotPageServlet\" method=\"post\"style=\"margin:100px 50px;\"><table><tr><td>Pilot ID:</td><td><input type=\"number\" name=\"id\" value=\""+id+"\"</td></tr><tr><td>License Number:</td><td><input type=\"text\" name=\"lic_num\" value=\""+rs.getString(2)+"\"></td>");
	            	planes.append("</tr><tr><td>Address 1:</td><td><input type=\"text\" name=\"addr1\" value=\""+rs.getString(3)+"\"></td></tr><tr><td>Address 2:</td><td><input type=\"text\" name=\"addr2\" value=\""+rs.getString(4)+"\"></td></tr><tr><td>City:</td><td><input type=\"text\" name=\"city\" value=\""+rs.getString(5)+"\"></td></tr><tr><td>State:</td><td><input type=\"text\" name=\"state\" value=\""+rs.getString(6)+"\"></td></tr>");
	            	planes.append("<tr><td>Zip Code:</td><td><input type=\"text\" name=\"zipcode\" value=\""+rs.getString(7)+"\"></td><tr><td>SSN:</td><td><input type=\"number\" name=\"ssn\" value=\""+rs.getInt(8)+"\"</tr><tr><td><input type=\"submit\" value=\"submit\"></td></tr></table>	</form></center></body>	</html>");
	              }
	              return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
	}
}
