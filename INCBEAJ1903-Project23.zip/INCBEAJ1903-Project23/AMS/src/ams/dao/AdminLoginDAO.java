package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import ams.model.AdminModel;

public class AdminLoginDAO {
	public boolean checkDatabase(AdminModel am)
	{
	       
	       try
	       {
	              System.out.println("AdminLoginDAO");
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              PreparedStatement pstmt=con.prepareStatement("select admin_id,password from admin where admin_id=? and password=?;");
	              pstmt.setString(1,am.getAdminId());
	              pstmt.setString(2,am.getPassword());
	              ResultSet rs=pstmt.executeQuery();            
	              if(rs.next())
	              {
	                     System.out.println("If");
	                     return true;
	              }
	              else
	              {
	                     System.out.println("Else");
	                     return false;
	              }

	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return false;
	       }
	}
}
