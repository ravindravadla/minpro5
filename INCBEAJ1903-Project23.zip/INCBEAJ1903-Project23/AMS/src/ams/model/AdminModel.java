package ams.model;

public class AdminModel {
private String adminId,age,contactNumber,alternateContactNumber;
private String firstName,lastName,gender,dob,emaiLId,password;
public String getAdminId() {
	return adminId;
}
public void setAdminId(String adminId) {
	this.adminId = adminId;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getContactNumber() {
	return contactNumber;
}
public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}
public String getAlternateContactNumber() {
	return alternateContactNumber;
}
public void setAlternateContactNumber(String alternateContactNumber) {
	this.alternateContactNumber = alternateContactNumber;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getEmaiLId() {
	return emaiLId;
}
public void setEmaiLId(String emaiLId) {
	this.emaiLId = emaiLId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

}
