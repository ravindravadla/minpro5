package ams.model;

public class HangarStatusModel {
private String hangarId,managerId,status,occupancyFromDate,occupancyTillDate,availableFromDate,availableTillDate;

public String getHangarId() {
	return hangarId;
}

public void setHangarId(String hangarId) {
	this.hangarId = hangarId;
}

public String getManagerId() {
	return managerId;
}

public void setManagerId(String managerId) {
	this.managerId = managerId;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public String getOccupancyFromDate() {
	return occupancyFromDate;
}

public void setOccupancyFromDate(String occupancyFromDate) {
	this.occupancyFromDate = occupancyFromDate;
}

public String getOccupancyTillDate() {
	return occupancyTillDate;
}

public void setOccupancyTillDate(String occupancyTillDate) {
	this.occupancyTillDate = occupancyTillDate;
}

public String getAvailableFromDate() {
	return availableFromDate;
}

public void setAvailableFromDate(String availableFromDate) {
	this.availableFromDate = availableFromDate;
}

public String getAvailableTillDate() {
	return availableTillDate;
}

public void setAvailableTillDate(String availableTillDate) {
	this.availableTillDate = availableTillDate;
}

}
