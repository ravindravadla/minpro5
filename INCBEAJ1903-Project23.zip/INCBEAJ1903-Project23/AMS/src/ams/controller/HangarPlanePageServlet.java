package ams.controller;
import ams.dao.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HangarPlanePageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();
	System.out.println(request.getParameter("h_id"));
	//String hid=request.getParameter("id"),id=request.getParameter("manager_id"),status=request.getParameter("status"),ofd=request.getParameter("ofd"),otd=request.getParameter("otd"),afd=request.getParameter("afd"),atd=request.getParameter("atd");
	String hid=request.getParameter("h_id"),p_id=request.getParameter("ups");
	HangarPlanePageSubmitDAO hppd=new HangarPlanePageSubmitDAO();
	//hppd.insertHangar(hid,id,status,ofd,otd,afd,atd);
	//hppd.insertHangar(hid, id);
	//response.sendRedirect("");
	out.println("<html><head><title>Hangar Status</title></head><body>");
	out.println("<form action=\"HangarPlanePageSubmitServlet\"><center><table>");
	out.println("<input type=\"hidden\" name=\"p_id\"value=\""+p_id+"\"></input></td></tr>");
	out.println("<tr><td>Manager ID</td><td><input type=\"text\" name=\"manager_id\"></input></td></tr>");
	//out.println("<tr><td>Status</td><td><input type=\"text\" name=\"status\"></input></td></tr>");
	//new line
	out.println("<tr><td>Status</td><td><select name='status'><option value='A'>Available</option><option value='O'>Occupied</option></select>");
	//end
	out.println("<tr><td>Occupancy From Date</td><td><input type=\"text\" name=\"ofd\"></input></td></tr>");
	out.println("<tr><td>Occupancy Till Date</td><td><input type=\"text\" name=\"otd\"></input></td></tr><tr><td>Available from Date</td><td><input type=\"text\" name=\"afd\"></input></td></tr>");
	out.println("<tr><td>Available till Date</td><td><input type=\"text\" name=\"atd\"></input></td></tr>");
	out.println("<input type=\"hidden\" id=\"h_id\" name=\"h_id\" value=\""+hid+"\"></table><input type=\"submit\" value=\"Submit\"></input></center></form></body></html>");
	}

}
