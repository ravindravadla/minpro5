package ams.controller;
import ams.dao.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class VerifyManagerStatusPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String id=request.getParameter("status");
		System.out.println("Hi "+id);
		VerifyManagerStatusPageDAO vmspd=new VerifyManagerStatusPageDAO();
		out.println("<html><head><title>View Manager</title></head><body>");
		out.println(vmspd.getManagerDetails(id));
		out.println("</body></html>");
	}

	
	
}
