package ams.controller;
import ams.dao.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AccRejManagerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String safe=request.getParameter("ups");
		String status=safe.substring(0, 8);
		String id=safe.substring(8);
		VerifyManagerStatusPageDAO vmspd=new VerifyManagerStatusPageDAO();
		int v=vmspd.acceptStatus(id, status);
		if(v==1)
		{
			out.println("Accepted");
			response.sendRedirect("VerifyManager.html");
		}
		else if(v==2)
		{
			out.println("Rejected");
			response.sendRedirect("VerifyManager.html");
		}
		else
		{
			out.println("Error");
		}
	}

	

}
