package ams.controller;
import ams.dao.*;
import ams.model.AdminModel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
     {
                     response.setContentType("text/html");
                     PrintWriter out=response.getWriter();
                     String adminId=request.getParameter("txtu");
                     String password=request.getParameter("txtp");
                     AdminModel am=new AdminModel();
                     am.setAdminId(adminId);
                     am.setPassword(password);
                     AdminLoginDAO ld=new AdminLoginDAO();
                     boolean check=ld.checkDatabase(am);
                     if(check)
                     {
                                     out.println("Login Sucess<br>");
 //out.println("<html><head><title>Planes</title></head><body><a href=\"AddPlanes.html\">Add Planes</a><br><a href=\"UpdatePlanes\">Update Planes</a><br><a href=\"ViewPlaneServlet\">View Planes</a></body></html>");
                                     response.sendRedirect("AdminAuthentication.html");
                     }
                     else
                     {
                                     out.println("Incorrect Password");
                                     request.getRequestDispatcher("HomePage.html").include(request, response);
                     }
                     
     }


}
