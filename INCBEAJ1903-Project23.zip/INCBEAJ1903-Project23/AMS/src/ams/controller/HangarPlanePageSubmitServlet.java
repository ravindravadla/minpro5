package ams.controller;
import ams.dao.*;
import ams.model.HangarStatusModel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HangarPlanePageSubmitServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String pid=request.getParameter("p_id");
		String hangarId=request.getParameter("h_id");
		String managerId=request.getParameter("manager_id");
		String status=request.getParameter("status");
		String occupancyFromDate=request.getParameter("ofd");
		String occupancyTillDate=request.getParameter("otd");
		String availableFromDate=request.getParameter("afd");
		String availableTillDate=request.getParameter("atd");
		//String hid=request.getParameter("h_id"),id=request.getParameter("ups");
		HangarPlanePageSubmitDAO hppd=new HangarPlanePageSubmitDAO();
		HangarStatusModel hsm=new HangarStatusModel();
		hsm.setHangarId(hangarId);
		hsm.setManagerId(managerId);
		hsm.setStatus(status);
		hsm.setOccupancyFromDate(occupancyFromDate);
		hsm.setOccupancyTillDate(occupancyTillDate);
		hsm.setAvailableFromDate(availableFromDate);
		hsm.setAvailableTillDate(availableTillDate);
		int i=hppd.insertHangar(pid,hsm);
		if(i>0)
		{
			out.println("Inserted");
			request.getRequestDispatcher("ManagerAuthentication.html").include(request, response);
		}
		else
		{
			out.println("Error");
		}
		//hppd.insertHangar(hid, id);
	}

}
