package ams.controller;
import ams.dao.*;
import ams.model.PilotModel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UpdatePilotPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String pilotId=request.getParameter("id");
		String licenseNumber=request.getParameter("lic_num");
		String address1=request.getParameter("addr1");
		String address2=request.getParameter("addr2");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String zipcode=request.getParameter("zipcode");
		String ssn=request.getParameter("ssn");
		UpdatePilotPageDAO uppd=new UpdatePilotPageDAO();
		PilotModel pm=new PilotModel();
		pm.setPilotId(pilotId);
		pm.setLicenseNumber(licenseNumber);
		pm.setAddress1(address1);
		pm.setAddress2(address2);
		pm.setCity(city);
		pm.setState(state);
		pm.setZipcode(zipcode);
		pm.setSsn(ssn);
		boolean v=uppd.updatePilotDetails(pm);
		if(v)
		{
			out.println("Updated<br>");
			request.getRequestDispatcher("Pilots.html").include(request,response);
		}
		else
		{
			out.println("Error");
		}
	}


}
