package ams.controller;
import ams.dao.*;
import ams.model.PlaneModel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UpdatePlanePageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String ownerId=request.getParameter("id");
		String ownerFirstName=request.getParameter("fname");
		String ownerLastName=request.getParameter("lname");
		String contactNumber=request.getParameter("num");
		String emailId=request.getParameter("email");
		String type=request.getParameter("type");
		String capacity=request.getParameter("cap");
		PlaneModel pm=new PlaneModel();
		pm.setOwnerId(ownerId);
		pm.setOwnerFirstName(ownerFirstName);
		pm.setOwnerLastName(ownerLastName);
		pm.setContactNumber(contactNumber);
		pm.setEmailId(emailId);
		pm.setType(type);
		pm.setCapacity(capacity);
		UpdatePlanePageDAO uppd=new UpdatePlanePageDAO();
		boolean v=uppd.updatePlaneDetails(pm);
		if(v)
		{
			out.println("Updated<br>");
			request.getRequestDispatcher("Planes.html").include(request, response);
		}
		else
		{
			out.println("Error");
		}
	}

}
