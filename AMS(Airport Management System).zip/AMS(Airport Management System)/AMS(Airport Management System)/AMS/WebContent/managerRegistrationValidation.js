function formValidation()
{
var fname = document.registration.fname;
var lname = document.registration.lname;
var age = document.registration.age;
//var gender = document.registration.gender;
//var dob = document.registration.dob;
var num = document.registration.num;
var anum = document.registration.anum;
var email = document.registration.email;
var pass = document.registration.pass; 

//New
var count;
count=0;
var check;
check=/^[A-Za-z]+$/;
if (fname.value.match(check))
{

}
else
{
//alert("First name should contains character");
//fname.focus();
fname.style.backgroundColor="red";
count=count+1;
//return false;
}

check=/^[A-Za-z]+$/;
if (lname.value.match(check))
{
	//return true;
}
else
{
//alert("Last name should contains character");
//lname.focus();
	lname.style.backgroundColor="red";
	count=count+1;
//return false;
}

check=/^[0-9]{2}$/;
if (age.value.match(check))
{
	//return true;
}
else
{
//alert("Age must contain number");
//age.focus();
	age.style.backgroundColor="red";
	count=count+1;
//return false;
}

check=/^[0-9]+$/;
if (num.value.match(check))
{
	//return true;
}
else
{
//alert("Contact must contain number");
//num.focus();
	num.style.backgroundColor="red";
	count=count+1;
//return false;
}


check=/^[0-9]+$/;
if (anum.value.match(check))
{
	//return true;
}
else
{
//alert("Alternate Contact must contain number");
//anum.focus();
	anum.style.backgroundColor="red";
	count=count+1;
//return false;
}


mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(email.value.match(mailformat))
{
//return true;
}
else
{
//alert("You have entered an invalid email address!");
//email.focus();
	email.style.backgroundColor="red";
	count=count+1;
//return false;
}



if (pass.value.length>0)
{

}
else
{
//alert("First name should contains character");
//fname.focus();
pass.style.backgroundColor="red";
count=count+1;
//return false;
}


if(count==0)
	{
	return true;
	}
else
	{
	alert("Fill the wrong details");
	return false;
	}


}
//End
//Correct
