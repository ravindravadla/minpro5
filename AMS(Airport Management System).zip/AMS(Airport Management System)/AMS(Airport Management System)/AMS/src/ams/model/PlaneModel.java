package ams.model;

public class PlaneModel {
private String planeId,ownerId,ownerFirstName,ownerLastName,contactNumber,emailId,type,capacity;

public String getPlaneId() {
	return planeId;
}

public void setPlaneId(String planeId) {
	this.planeId = planeId;
}

public String getOwnerId() {
	return ownerId;
}

public void setOwnerId(String ownerId) {
	this.ownerId = ownerId;
}

public String getOwnerFirstName() {
	return ownerFirstName;
}

public void setOwnerFirstName(String ownerFirstName) {
	this.ownerFirstName = ownerFirstName;
}

public String getOwnerLastName() {
	return ownerLastName;
}

public void setOwnerLastName(String ownerLastName) {
	this.ownerLastName = ownerLastName;
}

public String getContactNumber() {
	return contactNumber;
}

public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}

public String getEmailId() {
	return emailId;
}

public void setEmailId(String emailId) {
	this.emailId = emailId;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

public String getCapacity() {
	return capacity;
}

public void setCapacity(String capacity) {
	this.capacity = capacity;
}


}
