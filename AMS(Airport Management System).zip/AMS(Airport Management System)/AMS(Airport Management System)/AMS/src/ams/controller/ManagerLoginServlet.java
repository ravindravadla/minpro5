package ams.controller;
import ams.dao.*;
import ams.model.ManagerModel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ManagerLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
     {
                     response.setContentType("text/html");
                     PrintWriter out=response.getWriter();
                     String managerId=request.getParameter("txtu");
                     String password=request.getParameter("txtp");
                     
                     ManagerLoginDAO ld=new ManagerLoginDAO();
                     ManagerModel mm=new ManagerModel();
                     mm.setManagerId(managerId);
                     mm.setPassword(password);
                     int check=ld.checkDatabase(mm);
                     if(check==1)
                     {
                                     out.println("Login Success");
                                     response.sendRedirect("ManagerAuthentication.html");
                     }
                     else if(check==2)
                     {
                    	  out.println("Please wait for the confirmation from the admin");
                          request.getRequestDispatcher("HomePage.html").include(request, response);
                     }
                     else
                     {
                                  out.println("Incorrect Password");
                                  request.getRequestDispatcher("HomePage.html").include(request, response);
                     }
                     
                     
     }

}
