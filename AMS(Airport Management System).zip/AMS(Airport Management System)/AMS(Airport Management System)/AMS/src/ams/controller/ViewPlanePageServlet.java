package ams.controller;
import ams.dao.*;
import ams.model.PlaneModel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewPlanePageServlet extends HttpServlet{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String id=request.getParameter("ups");
		System.out.println(id+"\tHello");
		ViewPlaneDAO upd=new ViewPlaneDAO();
		String s=upd.getPlaneDetails(id);
		out.println(s);
	}
}
