package ams.controller;
import ams.dao.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HangarPlaneServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HangarPlaneDAO hpd=new HangarPlaneDAO();
		String id=request.getParameter("id");
		System.out.println("HangarPlaneServlet "+id );
		out.println("<html><head><title>View Pilots</title></head><body>");
		out.println(hpd.getID(id));
		out.println("</body></html>");
	}

}
