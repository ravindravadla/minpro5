package ams.controller;
import ams.dao.*;
import ams.model.HangarModel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AddHangarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		AddHangarDAO pd=new AddHangarDAO();
		
		String managerId=request.getParameter("manager_id");
		String address1=request.getParameter("address1");
		String address2=request.getParameter("address2");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
	    String zipcode=request.getParameter("zipcode");
		HangarModel hm=new HangarModel();
		hm.setManagerId(managerId);
		hm.setAddress1(address1);
		hm.setAddress2(address2);
		hm.setCity(city);
		hm.setState(state);
		hm.setZipcode(zipcode);
		
		
		boolean check=pd.insertDatabase(hm);
		if(check)
		{
			out.println("Inserted<br>");
			request.getRequestDispatcher("Hangar.html").include(request, response);
		}
		else
		{
			out.println("Error");
		}
		
		// TODO Auto-generated method stub
	}

}
