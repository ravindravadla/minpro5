package ams.controller;
import ams.dao.*;
import ams.model.PlaneModel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




public class PlanesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		PlanesDAO pd=new PlanesDAO();
		int ownerId=pd.getOwnerID();
		String ownerFirstName=request.getParameter("fname");
		String ownerLastName=request.getParameter("lname");
		String contactNumber=request.getParameter("num");
		String emailId=request.getParameter("email");
		String type=request.getParameter("type");
		String capacity=request.getParameter("cap");
		PlaneModel pm=new PlaneModel();
		pm.setOwnerId(Integer.toString(ownerId));
		pm.setOwnerFirstName(ownerFirstName);
		pm.setOwnerLastName(ownerLastName);
		pm.setContactNumber(contactNumber);
		pm.setEmailId(emailId);
		pm.setType(type);
		pm.setCapacity(capacity);
		boolean check=pd.insertDatabase(pm);
		if(check)
		{
			out.println("Inserted");
			request.getRequestDispatcher("Planes.html").include(request,response);
		}
		else
		{
			out.println("Error");
		}
		
	}


		// TODO Auto-generated method stub
	}