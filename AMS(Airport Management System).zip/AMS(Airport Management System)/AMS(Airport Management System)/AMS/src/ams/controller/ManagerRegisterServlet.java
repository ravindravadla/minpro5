package ams.controller;
import ams.dao.*;
import ams.model.ManagerModel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ManagerRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/plain");
		PrintWriter out=response.getWriter();
		String firstName=request.getParameter("fname");
		String lastName=request.getParameter("lname");
		String age=request.getParameter("age");
		String gender=request.getParameter("gender");
		String dob=request.getParameter("dob");
		String contactNumber=request.getParameter("num");
		String alternateContactNumber=request.getParameter("anum");
		String emaiLId=request.getParameter("email");
		String password=request.getParameter("pass");
		ManagerRegisterDAO mrd=new ManagerRegisterDAO();
		ManagerModel mm=new ManagerModel();
		mm.setFirstName(firstName);
		mm.setLastName(lastName);
		mm.setAge(age);
		mm.setGender(gender);
		mm.setDob(dob);
		mm.setContactNumber(contactNumber);
		mm.setAlternateContactNumber(alternateContactNumber);
		mm.setEmaiLId(emaiLId);
		mm.setPassword(password);
		boolean check=mrd.insertDatabase(mm);
		if(check)
		{
			out.println("Inserted");
			response.sendRedirect("HomePage.html");
		}
		else
		{
			out.println("Error");
		}
		
	}

}
