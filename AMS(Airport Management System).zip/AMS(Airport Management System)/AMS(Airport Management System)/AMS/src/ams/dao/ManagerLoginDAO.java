package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import ams.model.ManagerModel;

public class ManagerLoginDAO {
	public int checkDatabase(ManagerModel mm)
	{
	       
	       try
	       {
	              System.out.println("ManagerLoginServlet "+mm.getManagerId()+"\t"+mm.getPassword());
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              PreparedStatement pstmt=con.prepareStatement("select manager_id,password from manager where manager_id=? and password=?;");
	              PreparedStatement pstmt1=con.prepareStatement("select status from manager_status where manager_id=?;");
	              pstmt.setString(1,mm.getManagerId());
	              pstmt.setString(2,mm.getPassword());
	              pstmt1.setString(1,mm.getManagerId());
	              ResultSet rs=pstmt.executeQuery();      
	              ResultSet rs1=pstmt1.executeQuery();    
	              String status="";
	              if(rs1.next())
	              {
	              status=rs1.getString(1);
	              }
	               if(rs.next())
	              {
	                     System.out.println("ManagerLoginServlet If");  
	                     
	   	              System.out.println("ManagerLoginServlet Status "+status);

	                     if(status.equalsIgnoreCase("accepted"))
	                    	 {
	                    	 System.out.println("ManagerLoginServlet1 "+status);
	                    	 return 1;
	                    	 }
	                     else
	                     { 
	                    	 System.out.println("ManagerLoginServlet2 Status "+status);
	                    	 return 2;
	                    	 }
	              }
	              else
	              {
	            	  
	                     System.out.println("Else");
	                     return 3;
	              }

	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return 4;
	       }
	}
}
