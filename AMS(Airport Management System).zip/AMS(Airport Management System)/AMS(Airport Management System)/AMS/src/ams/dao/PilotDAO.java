package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import ams.model.PilotModel;

public class PilotDAO
{
	public boolean insertDatabase(PilotModel pm )
	{
	       
	       try
	       {
	              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              PreparedStatement pstmt=con.prepareStatement("insert into pilots(lic_num,addr1, addr2,city,state,zipcode,ssn) values(?,?,?,?,?,?,?);");
	              
	              pstmt.setString(1,pm.getLicenseNumber());
	              pstmt.setString(2,pm.getAddress1());
	              pstmt.setString(3,pm.getAddress2());
	              pstmt.setString(4,pm.getCity());
	              pstmt.setString(5,pm.getState());
	              pstmt.setInt(6,Integer.parseInt(pm.getZipcode()));
	              pstmt.setInt(7,Integer.parseInt(pm.getSsn()));
	          
	             
	             int rec=pstmt.executeUpdate();   
	             System.out.println(rec);
	              if(rec>0)
	              {
	                     System.out.println(rec);
	                     return true;
	              }
	              else
	              {
	                     System.out.println("No record");
	                     return false;
	              }

	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return false;
	       }
}

}
