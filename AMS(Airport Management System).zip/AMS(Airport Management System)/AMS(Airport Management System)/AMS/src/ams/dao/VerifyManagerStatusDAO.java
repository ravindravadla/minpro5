package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class VerifyManagerStatusDAO
{
	public String verifyManager() 
	{
		try{
	Class.forName("com.mysql.jdbc.Driver");
    Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
    PreparedStatement pstmt=con.prepareStatement("select manager.manager_id from manager left join manager_status on manager.manager_id=manager_status.manager_id where manager_status.manager_id is null;");
    ResultSet rs=pstmt.executeQuery();
    StringBuffer sb=new StringBuffer();
    sb.append("<html><head><title>Verify Manager</title></head><body><form action=\"VerifyManagerStatusPageServlet\">");
    while(rs.next())
    {
    	sb.append("<input type=\"submit\" name=\"status\" value=\"");
    	sb.append(rs.getString(1)+"\"</input><br>");
    }
    sb.append("</form></body></html>");
    return sb.toString();
		}
		catch(Exception e)
		{
			System.out.println(e);
			return null;
		}
	}
}
