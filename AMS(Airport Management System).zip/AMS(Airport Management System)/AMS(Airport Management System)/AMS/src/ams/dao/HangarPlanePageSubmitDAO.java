package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import ams.model.HangarStatusModel;

public class HangarPlanePageSubmitDAO {
	public int insertHangar(String pid,HangarStatusModel hsm)
	{
		
		try
	    {
	           
	           Class.forName("com.mysql.jdbc.Driver");
	           Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	           PreparedStatement pstmt=con.prepareStatement("insert into hangar_status values(?,?,?,?,?,?,?);");   
	           PreparedStatement pstmt1=con.prepareStatement("insert into hangarplane values(?,?);");   
	           pstmt.setString(1,hsm.getHangarId());
	           pstmt.setString(2,hsm.getManagerId());
	           pstmt.setString(3,hsm.getStatus());
	           pstmt.setString(4,hsm.getOccupancyFromDate());
	           pstmt.setString(5,hsm.getOccupancyTillDate());
	           pstmt.setString(6,hsm.getAvailableFromDate());
	           pstmt.setString(7,hsm.getAvailableTillDate());
	           pstmt1.setString(1, hsm.getHangarId());
	           pstmt1.setString(2, pid);
	               int i=pstmt.executeUpdate();
	               int j=pstmt1.executeUpdate();
	          if(i>0&&j>0)
	          {
	        	  return 1;
	          }
	          else 
	          {
	        	  return 0;
	          }
	         

	    } 
	    catch(Exception e)
	    {
	           System.out.println(e);
	           return 0;
	    }
	}
}
