package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import ams.model.PilotModel;

public class UpdatePilotPageDAO {
	public boolean updatePilotDetails(PilotModel pm)
	{
				  
	       try
	       {
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              	              
	              PreparedStatement pstmt=con.prepareStatement("update pilots set lic_num=?,addr1=?,addr2=?,city=?,state=?,zipcode=?,ssn=? where pilot_id=?");   
	              pstmt.setString(1,pm.getLicenseNumber());
	              pstmt.setString(2,pm.getAddress1());
	              pstmt.setString(3,pm.getAddress2());
	              pstmt.setString(4,pm.getCity());
	              pstmt.setString(5,pm.getState());
	              pstmt.setString(6,pm.getZipcode());
	              pstmt.setInt(7, Integer.parseInt(pm.getSsn()));
	              pstmt.setInt(8,Integer.parseInt(pm.getPilotId()));
	              int i=pstmt.executeUpdate();
	              if(i>0)
	              return true;
	              else
	              return false;
	              
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return false;
	       }
	}
}
