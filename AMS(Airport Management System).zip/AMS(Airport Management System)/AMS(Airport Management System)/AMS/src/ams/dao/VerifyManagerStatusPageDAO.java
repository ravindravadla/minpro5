package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class VerifyManagerStatusPageDAO {
	public String getManagerDetails(String id)
	{
	       
	       try
	       {
	              //System.out.println(user+"\t"+pass);
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              StringBuffer sb=new StringBuffer();
	             
	              PreparedStatement pstmt=con.prepareStatement("select * from manager where manager_id=?;");   
	              pstmt.setString(1, id);
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              
	              if(rs.next())
	              {
	            	  planes.append("<style>table,tr,td{border:1px solid black}</style>");
	            	  planes.append("<table>");
	            	  planes.append("<tr><td>Manager ID:</td><td>"+rs.getInt(1));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>First Name:</td><td>"+rs.getString(2));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Last Name:</td><td>"+rs.getString(3));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Age:</td><td>"+rs.getInt(4));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Gender:</td><td>"+rs.getString(5));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>DOB:</td><td>"+rs.getString(6));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Contact Number:</td><td>"+rs.getString(7));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Alternate Contact Number:</td><td>"+rs.getString(8));
	            	  planes.append("<tr><td>Email ID:</td><td>"+rs.getString(9));
	            	  planes.append("</td></tr></table>");
	            	  planes.append("<form action=\"AccRejManagerServlet\">");
	            	  planes.append("<input type=\"submit\" name=\"ups\" value=\"Accepted"+rs.getInt(1)+"\"></input>");
	            	  planes.append("<input type=\"submit\" name=\"ups\" value=\"Rejected"+rs.getInt(1)+"\"></input>");
	            	  planes.append("</form>");	            	      	 
	              }
	              
	             // System.out.println(planes);
	              
	             
	              	return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
	}
	public int acceptStatus(String id,String status)
	{
		try
	       {
	              //System.out.println(user+"\t"+pass);
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              StringBuffer sb=new StringBuffer();
	             
	              PreparedStatement pstmt=con.prepareStatement("insert into manager_status values(?,?);");   
	                pstmt.setString(1,id);
	                pstmt.setString(2,status);
	              int i=pstmt.executeUpdate();
	              
	             if(i>0&&status.equalsIgnoreCase("accepted"))
	              	return 1;
	             else if(i>0&&status.equalsIgnoreCase("rejected"))
	            	 return 2;
	             else
	            	 return 3;
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return 0;
	       }
	}
}
