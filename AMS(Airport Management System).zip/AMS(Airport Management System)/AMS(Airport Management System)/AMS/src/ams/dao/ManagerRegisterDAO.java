package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import ams.model.ManagerModel;

public class ManagerRegisterDAO {
	
	public boolean insertDatabase(ManagerModel mm)
	{
	       
	       try
	       {
	              //System.out.println(user+"\t"+pass);
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              
	             
	              PreparedStatement pstmt=con.prepareStatement("insert into manager(first_name,last_name,age,gender,Dob,con_num,alt_con_num,email_id,password) values(?,?,?,?,?,?,?,?,?);");
	              
	              pstmt.setString(1,mm.getFirstName());
	              pstmt.setString(2,mm.getLastName());
	              pstmt.setString(3,mm.getAge());
	              pstmt.setString(4,mm.getGender());
	              pstmt.setString(5,mm.getDob());
	              pstmt.setString(6,mm.getContactNumber());
	              pstmt.setString(7,mm.getAlternateContactNumber());
	              pstmt.setString(8,mm.getEmaiLId());
	              pstmt.setString(9,mm.getPassword());
	              
	              int rec=pstmt.executeUpdate();   
	              System.out.println(rec);
	              if(rec>0)
	              {
	                     System.out.println(rec);
	                     return true;
	              }
	              else
	              {
	                     System.out.println("No record");
	                     return false;
	              }

	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return false;
	       }
	}
}
