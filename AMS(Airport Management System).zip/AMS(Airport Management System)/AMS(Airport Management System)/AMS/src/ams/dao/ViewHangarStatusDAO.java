package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewHangarStatusDAO {
public String getHangarStatus()
{
	 try
     {
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");                      
            PreparedStatement pstmt=con.prepareStatement("select hangar_id,status from hangar_status;");                            
            ResultSet rs=pstmt.executeQuery();   
            StringBuffer sb=new StringBuffer();
            sb.append("<html><body><table>");
            while(rs.next())
            {
            	sb.append("<tr><td>Hangar ID:</td><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td></tr>");
            }
           sb.append("</table></body></html>");
           return sb.toString();
     }
     catch(Exception e)
     {
            System.out.println(e);
             return null;
     }

}
}
