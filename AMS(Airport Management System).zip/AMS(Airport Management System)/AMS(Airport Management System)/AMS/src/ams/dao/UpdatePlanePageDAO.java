package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import ams.model.*;
public class UpdatePlanePageDAO {
	public boolean updatePlaneDetails(PlaneModel pm)
	{
				  
	       try
	       {
	              	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              	              
	              PreparedStatement pstmt=con.prepareStatement("update planes set ofn=?,oln=?,o_num=?,o_email=?,plane_type=?,plane_cap=? where plane_id=?");   
	              pstmt.setString(1,pm.getOwnerFirstName());
	              pstmt.setString(2,pm.getOwnerLastName());
	              pstmt.setString(3,pm.getContactNumber());
	              pstmt.setString(4,pm.getEmailId());
	              pstmt.setString(5,pm.getType());
	              pstmt.setInt(6,Integer.parseInt(pm.getCapacity()));
	              pstmt.setInt(7, Integer.parseInt(pm.getOwnerId()));
	              int i=pstmt.executeUpdate();
	              if(i>0)
	              return true;
	              else
	            	 return false;
	              
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return false;
	       }
	}
}
