package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import ams.model.PlaneModel;


public class PlanesDAO {
	
	
	public boolean insertDatabase(PlaneModel pm)
	{
	       
	       try
	       {
	              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              
	              System.out.println("PlanesDAO");
	              PreparedStatement pstmt=con.prepareStatement("insert into planes(owner_id,ofn,oln,o_num,o_email,plane_type,plane_cap) values(?,?,?,?,?,?,?);");
	              pstmt.setInt(1,Integer.parseInt(pm.getOwnerId()));
	              pstmt.setString(2,pm.getOwnerFirstName());
	              pstmt.setString(3,pm.getOwnerLastName());
	              //pstmt.setInt(4,Integer.parseInt(pm.getContactNumber()));
	              pstmt.setString(4,pm.getContactNumber());
	              pstmt.setString(5,pm.getEmailId());
	              pstmt.setString(6,pm.getType());
	              pstmt.setInt(7,Integer.parseInt(pm.getCapacity()));
	          
	             
	              int rec=pstmt.executeUpdate();   
	              System.out.println(rec);
	              if(rec>0)
	              {
	                     System.out.println(rec);
	                     return true;
	              }
	              else
	              {
	                     System.out.println("No record");
	                     return false;
	              }

	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return false;
	       }
}
	public int getOwnerID()
	{
	       
	       try
	       {	              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              
	              
	              PreparedStatement pstmt=con.prepareStatement("select owner_id from planes order by owner_id desc;");
	           	       	             
	              ResultSet rs=pstmt.executeQuery();   
	              int count=1;
	             if(rs.next())
	             {
	            	 count=rs.getInt(1)+1;
	             }
	             	return count;
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return 0;
	       }
}
}
