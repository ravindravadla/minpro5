package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AllotHangarDAO {
public String getHangarID()
{
	try
    {
           
           Class.forName("com.mysql.jdbc.Driver");
           Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
           PreparedStatement pstmt=con.prepareStatement("select hangar.hangar_id from hangar left join hangar_status on hangar.hangar_id=hangar_status.hangar_id where status='A' or status is null");              
          ResultSet rs=pstmt.executeQuery();
          StringBuffer sb=new StringBuffer();
          sb.append("<html><body><form action=\"HangarPlaneServlet\"><table>");
          while(rs.next())
          {
        	  //sb.append("<tr><td><input type=\"hidden\" value=\""+rs.getInt(1)+"\"</td></tr>");
        	  sb.append("<tr><td><input type=\"submit\" name=\"id\" value=\""+rs.getInt(1)+"\"</td></tr>");
          }
          sb.append("</table></form></body></html>");
          return sb.toString();

    } 
    catch(Exception e)
    {
           System.out.println(e);
           return null;
    }
}
}
