package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewHangarDAO {
	public String getID()
	{
	       
	       try
	       {              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              
	              
	              PreparedStatement pstmt=con.prepareStatement("select hangar_id from hangar");   
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer hangar=new StringBuffer();
	              hangar.append("<form action=\"ViewHangarPageServlet\">");
	              while(rs.next())
	              {
	            	  hangar.append("<input type=\"submit\" name=\"ups\" value=\"");
	            	  hangar.append(rs.getInt(1));
	            	  hangar.append("\">");
	            	
	            	  hangar.append("</input><br><br>");
	            	 
	              }
	              hangar.append("</form>");
	              System.out.println("Hangar"+hangar);
	              return hangar.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
}
	public String getHangarDetails(String id)
	{
				  
	       try
	       {
	              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              	              
	              PreparedStatement pstmt=con.prepareStatement("select * from hangar where hangar_id=?;");   
	              pstmt.setInt(1, Integer.parseInt(id));
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              if(rs.next())
	              {
	            	  planes.append("<html><body>");
	            	  planes.append("<table>");
	            	  planes.append("<tr><td>Hangar ID:</td><td>"+rs.getInt(1));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Manager ID:</td><td>"+rs.getString(2));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Address 1:</td><td>"+rs.getString(3));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Address 2:</td><td>"+rs.getString(4));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>City:</td><td>"+rs.getString(5));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>State:</td><td>"+rs.getString(6));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Zip Code:</td><td>"+rs.getString(7));            	 
	            	  planes.append("</td></tr></table>");	            	
	            	  planes.append("</form>");
	            	  planes.append("</body></html>");
	              }
	              return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
	}
	public String getHangarStatusDetails(String id)
	{
				  
	       try
	       {
	              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              	              
	              PreparedStatement pstmt=con.prepareStatement("select * from hangar where hangar_id=?;");   
	              pstmt.setInt(1, Integer.parseInt(id));
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              if(rs.next())
	              {
	            	  planes.append("<html><body>");
	            	  planes.append("<table>");
	            	  planes.append("<tr><td>Hangar ID:</td><td>"+rs.getInt(1));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Manager ID:</td><td>"+rs.getString(2));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Address 1:</td><td>"+rs.getString(3));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Address 2:</td><td>"+rs.getString(4));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>City:</td><td>"+rs.getString(5));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>State:</td><td>"+rs.getString(6));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Zip Code:</td><td>"+rs.getString(7));            	 
	            	  planes.append("</td></tr></table>");	            	
	            	  planes.append("</form>");
	            	  planes.append("</body></html>");
	              }
	              return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
	}
}
