package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class HangarPlaneDAO {
	public String getID(String id)
	{
	       
	       try
	       {              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              
	              
	              PreparedStatement pstmt=con.prepareStatement("select planes.plane_id from planes left join hangarplane on planes.plane_id=hangarplane.plane_id where hangar_id is null;");   
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              planes.append("<form action=\"HangarPlanePageServlet\">");
	              planes.append("<input type=\"hidden\" name=\"h_id\" value=\""+id+"\">");
	              while(rs.next())
	              {
	            	  planes.append("<input type=\"submit\" name=\"ups\" value=\"");
	            	  planes.append(rs.getString(1));
	            	  planes.append("\">");	            	
	            	  planes.append("</input><br><br>");	            	 
	              }
	              planes.append("</form>");
	              System.out.println(planes);
	              return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
}
}
