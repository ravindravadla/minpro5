package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewPilotDAO {
	public String getID()
	{
	       
	       try
	       {              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              
	              
	              PreparedStatement pstmt=con.prepareStatement("select pilot_id from pilots");   
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              planes.append("<form action=\"ViewPilotPageServlet\">");
	              while(rs.next())
	              {
	            	  planes.append("<input type=\"submit\" name=\"ups\" value=\"");
	            	  planes.append(rs.getString(1));
	            	  planes.append("\">");
	            	
	            	  planes.append("</input><br><br>");
	            	 
	              }
	              planes.append("</form>");
	              System.out.println(planes);
	              return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
}
	public String getPilotDetails(String id)
	{
				  
	       try
	       {
	              
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              	              
	              PreparedStatement pstmt=con.prepareStatement("select * from pilots where pilot_id=?;");   
	              pstmt.setInt(1, Integer.parseInt(id));
	              ResultSet rs=pstmt.executeQuery();   
	              StringBuffer planes=new StringBuffer();
	              if(rs.next())
	              {
	            	  planes.append("<html><body>");
	            	  planes.append("<style>table,tr,td{border:1px solid black;}</style>");
	            	  planes.append("<table>");
	            	  planes.append("<tr><td>Pilot ID:</td><td>"+rs.getInt(1));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>License Number:</td><td>"+rs.getString(2));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Address 1:</td><td>"+rs.getString(3));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Address 2:</td><td>"+rs.getString(4));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>City:</td><td>"+rs.getString(5));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>State:</td><td>"+rs.getString(6));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>Zip Code:</td><td>"+rs.getString(7));
	            	  planes.append("</td></tr>");
	            	  planes.append("<tr><td>SSN:</td><td>"+rs.getInt(8));
	            	  planes.append("</td></tr></table>");
	            	  planes.append("<form action=\"UpdatePilotServlet\"><input type=\"submit\" name=\"ups\" value=\""+id+"\">");
	            	  planes.append("Update Pilot</input></form>");
	            	  planes.append("</body></html>");
	              }
	              return planes.toString();
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return null;
	       }
	}
}
