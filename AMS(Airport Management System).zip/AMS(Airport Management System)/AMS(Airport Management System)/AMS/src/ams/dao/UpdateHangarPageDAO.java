package ams.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UpdateHangarPageDAO {
	public boolean updateHangarDetails(String id,String mid,String addr1,String addr2,String city,String state,String zipcode)
	{
				  
	       try
	       {
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/AirportManagementSystem","root","root");
	              	              
	              PreparedStatement pstmt=con.prepareStatement("update hangar set manager_id=?,address1=?,address2=?,city=?,state=?,zipcode=? where hangar_id=?");   
	              pstmt.setString(1,mid);
	              pstmt.setString(2,addr1);
	              pstmt.setString(3,addr2);
	              pstmt.setString(4,city);
	              pstmt.setString(5,state);
	              pstmt.setString(6,zipcode);
	              pstmt.setInt(7,Integer.parseInt(id));
	              int i=pstmt.executeUpdate();
	              if(i>0)
	              return true;
	              else
	              return false;
	              
	       }
	       catch(Exception e)
	       {
	              System.out.println(e);
	              return false;
	       }
	}
}
